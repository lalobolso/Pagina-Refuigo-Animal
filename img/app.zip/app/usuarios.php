<?php
include 'conexion.php';

// Eliminar usuario
if (isset($_GET['delete'])) {
    $cedula = $conn->real_escape_string($_GET['delete']);
    $conn->query("DELETE FROM usuarios WHERE Cedula='$cedula'");
}

// Añadir usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_user'])) {
    $cedula = $_POST['cedula'];
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $sexo = $_POST['sexo'];
    $contraseña = $_POST['contraseña'];
    $estado = 1;

    $sql = "INSERT INTO usuarios (Cedula, Nombre, Email, Sexo, Contrasenia, Estado)
            VALUES ('$cedula', '$nombre', '$email', '$sexo', '$contraseña', $estado)";
    $conn->query($sql);
}

// Modificar usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_user'])) {
    $cedula = $_POST['cedula'];
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $sexo = $_POST['sexo'];

    $sql = "UPDATE usuarios SET Nombre='$nombre', Email='$email', Sexo='$sexo' WHERE Cedula='$cedula'";
    $conn->query($sql);
}

// Consultar usuarios
$registrados = $conn->query("
    SELECT u.* FROM usuarios u
    JOIN participa p ON u.Cedula = p.Cedula_usuario
    GROUP BY u.Cedula
");

$no_registrados = $conn->query("
    SELECT u.* FROM usuarios u
    WHERE u.Cedula NOT IN (SELECT Cedula_usuario FROM participa)
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Usuarios</title>
  <link rel="stylesheet" href="css/admin.css">
            <link rel="icon" href="img/Qubit.png" type="image/x-icon">

</head>
<body>
  <div class="sidebar">
    <h2>Admin</h2>
    <ul>
      <li><a href="admin.php">🏠 Dashboard</a></li>
      <li><a href="usuarios.php">👥 Usuarios</a></li>
      <li><a href="carreras.php">🏃 Carreras</a></li>
            <li><a href="inscripciones.php">📝 Inscripciones</a></li>

      <li><a href="logout.php">🚪 Salir</a></li>
    </ul>
  </div>

  <div class="content">
    <h1>Gestión de Usuarios</h1>

    <!-- Formulario para añadir -->
    <h2>➕ Añadir Usuario</h2>
    <form method="POST">
      <input type="hidden" name="add_user" value="1">
      <label>Cédula:</label>
      <input type="text" name="cedula" required>
      <label>Nombre:</label>
      <input type="text" name="nombre" required>
      <label>Email:</label>
      <input type="email" name="email" required>
      <label>Sexo:</label>
      <select name="sexo" required>
        <option value="M">Masculino</option>
        <option value="F">Femenino</option>
        <option value="O">Otro</option>
      </select>
      <label>Contraseña:</label>
      <input type="password" name="contraseña" required>
      <button type="submit">Añadir</button>
    </form>

    <!-- Usuarios registrados -->
    <h2>📋 Usuarios Registrados en Carreras</h2>
    <table>
      <tr>
        <th>Cédula</th>
        <th>Nombre</th>
        <th>Email</th>
        <th>Sexo</th>
        <th>Acciones</th>
      </tr>
      <?php while($row = $registrados->fetch_assoc()): ?>
        <tr>
          <td><?= $row['Cedula'] ?></td>
          <td><?= $row['Nombre'] ?></td>
          <td><?= $row['Email'] ?></td>
          <td><?= $row['Sexo'] ?></td>
          <td>
            <!-- Formulario inline para editar -->
            <form method="POST" style="display:inline;">
              <input type="hidden" name="edit_user" value="1">
              <input type="hidden" name="cedula" value="<?= $row['Cedula'] ?>">
              <input type="text" name="nombre" value="<?= $row['Nombre'] ?>" required>
              <input type="email" name="email" value="<?= $row['Email'] ?>" required>
              <select name="sexo">
                <option value="M" <?= $row['Sexo']=="M"?"selected":"" ?>>M</option>
                <option value="F" <?= $row['Sexo']=="F"?"selected":"" ?>>F</option>
                <option value="O" <?= $row['Sexo']=="O"?"selected":"" ?>>O</option>
              </select>
              <button type="submit">Guardar</button>
            </form>
            <a href="usuarios.php?delete=<?= $row['Cedula'] ?>" onclick="return confirm('¿Eliminar usuario?')">🗑 Eliminar</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>

    <!-- Usuarios no registrados -->
    <h2>👤 Usuarios NO Registrados en Carreras</h2>
    <table>
      <tr>
        <th>Cédula</th>
        <th>Nombre</th>
        <th>Email</th>
        <th>Sexo</th>
        <th>Acciones</th>
      </tr>
      <?php while($row = $no_registrados->fetch_assoc()): ?>
        <tr>
          <td><?= $row['Cedula'] ?></td>
          <td><?= $row['Nombre'] ?></td>
          <td><?= $row['Email'] ?></td>
          <td><?= $row['Sexo'] ?></td>
          <td>
            <!-- Formulario inline para editar -->
            <form method="POST" style="display:inline;">
              <input type="hidden" name="edit_user" value="1">
              <input type="hidden" name="cedula" value="<?= $row['Cedula'] ?>">
              <input type="text" name="nombre" value="<?= $row['Nombre'] ?>" required>
              <input type="email" name="email" value="<?= $row['Email'] ?>" required>
              <select name="sexo">
                <option value="M" <?= $row['Sexo']=="M"?"selected":"" ?>>M</option>
                <option value="F" <?= $row['Sexo']=="F"?"selected":"" ?>>F</option>
                <option value="O" <?= $row['Sexo']=="O"?"selected":"" ?>>O</option>
              </select>
              <button type="submit">Guardar</button>
            </form>
            <a href="usuarios.php?delete=<?= $row['Cedula'] ?>" onclick="return confirm('¿Eliminar usuario?')">🗑 Eliminar</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>
</body>
</html>
