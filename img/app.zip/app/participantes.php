<?php
include 'conexion.php';

if (!isset($_GET['id'])) {
    die("ID de carrera no válido");
}

$idCarrera = intval($_GET['id']);

// Eliminar corredor
if (isset($_GET['delete'])) {
    $cedula = $_GET['delete'];
    $conn->query("DELETE FROM participa WHERE Cedula_usuario='$cedula' AND ID_Carrera=$idCarrera");
}

// Añadir corredor
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cedula = $_POST['cedula'];
    $categoria = $_POST['categoria'];
    $anio = date("Y");
    $numero = rand(100, 999);

    $sql = "INSERT INTO participa (Cedula_usuario, ID_Carrera, Numero_de_corredor, Inscripto, Anio, Categoria) 
            VALUES ('$cedula', $idCarrera, $numero, 1, $anio, '$categoria')";
    $conn->query($sql);
}

// Consultar participantes
$result = $conn->query("SELECT p.Cedula_usuario, u.Nombre, p.Numero_de_corredor, p.Categoria, p.Tiempo 
                        FROM participa p 
                        JOIN usuarios u ON p.Cedula_usuario = u.Cedula
                        WHERE p.ID_Carrera=$idCarrera");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Participantes</title>
  <link rel="stylesheet" href="css/admin.css">
            <link rel="icon" href="img/Qubit.png" type="image/x-icon">

</head>
<body>
  <div class="sidebar">
    <h2>Admin</h2>
    <ul>
      <li><a href="admin.php">🏠 Dashboard</a></li>
      <li><a href="usuarios.php">👥 Usuarios</a></li>
      <li><a href="carreras.php">🏃 Carreras</a></li>
      <li><a href="logout.php">🚪 Salir</a></li>
    </ul>
  </div>

  <div class="content">
    <h1>Participantes de la Carrera #<?= $idCarrera ?></h1>

    <h2>Añadir Participante</h2>
    <form method="POST">
      <label>Cédula del Corredor:</label>
      <input type="text" name="cedula" required>

      <label>Categoría:</label>
      <input type="text" name="categoria" required>

      <button type="submit">Añadir</button>
    </form>

    <h2>Listado de Participantes</h2>
    <table>
      <tr>
        <th>Cédula</th>
        <th>Nombre</th>
        <th>Número</th>
        <th>Categoría</th>
        <th>Tiempo</th>
        <th>Acciones</th>
      </tr>
      <?php while($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= $row['Cedula_usuario'] ?></td>
          <td><?= $row['Nombre'] ?></td>
          <td><?= $row['Numero_de_corredor'] ?></td>
          <td><?= $row['Categoria'] ?></td>
          <td><?= $row['Tiempo'] ? $row['Tiempo'] : "Sin registro" ?></td>
          <td>
            <a href="participantes.php?id=<?= $idCarrera ?>&delete=<?= $row['Cedula_usuario'] ?>" 
               onclick="return confirm('¿Seguro que deseas eliminar este participante?')">🗑 Eliminar</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>
</body>
</html>
