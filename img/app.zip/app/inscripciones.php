<?php
include 'conexion.php';

// Consulta uniendo usuarios, participa, carrera y pago
$sql = "SELECT u.Nombre, u.Cedula, c.Nombre AS Carrera, p.Anio, 
               p.Categoria, pg.Estado, pg.Comprobante
        FROM participa p
        INNER JOIN corredor co ON p.Cedula_usuario = co.Cedula_usuario
        INNER JOIN usuarios u ON co.Cedula_usuario = u.Cedula
        INNER JOIN carrera c ON p.ID_Carrera = c.ID_Carrera
        LEFT JOIN pago pg ON p.ID_Carrera = pg.ID_Carrera";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inscripciones</title>
  <link rel="stylesheet" href="css/admin.css">
            <link rel="icon" href="img/Qubit.png" type="image/x-icon">

</head>
<body>
      <div class="sidebar">
    <h2>Admin</h2>
    <ul>
      <li><a href="admin.php">🏠 Dashboard</a></li>
      <li><a href="usuarios.php">👥 Usuarios</a></li>
      <li><a href="carreras.php">🏃 Carreras</a></li>
            <li><a href="inscripciones.php">📝 Inscripciones</a></li>

      <li><a href="logout.php">🚪 Salir</a></li>
    </ul>
  </div>
  <div class="content">
    <h1>Inscripciones de Usuarios</h1>
    
    <table>
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Cédula</th>
          <th>Carrera</th>
          <th>Año de Inscripción</th>
          <th>Categoría</th>
          <th>Estado del Pago</th>
          <th>Comprobante</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows > 0): ?>
          <?php while($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?php echo htmlspecialchars($row['Nombre']); ?></td>
              <td><?php echo htmlspecialchars($row['Cedula']); ?></td>
              <td><?php echo htmlspecialchars($row['Carrera']); ?></td>
              <td><?php echo htmlspecialchars($row['Anio']); ?></td>
              <td><?php echo htmlspecialchars($row['Categoria']); ?></td>
              <td><?php echo htmlspecialchars($row['Estado'] ?? 'Pendiente'); ?></td>
              <td>
                <?php if (!empty($row['Comprobante'])): ?>
                  <a href="uploads/<?php echo $row['Comprobante']; ?>" target="_blank">Ver</a>
                <?php else: ?>
                  No subido
                <?php endif; ?>
              </td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr>
            <td colspan="7">No hay inscripciones registradas.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
