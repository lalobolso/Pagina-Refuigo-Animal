<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel de Administración</title>
  <link rel="stylesheet" href="css/admin.css">
          <link rel="icon" href="img/Qubit.png" type="image/x-icon">
</head>
<body>
  <div class="sidebar">
    <h2>Admin</h2>
    <ul>
      <li><a href="admin.php">🏠 Dashboard</a></li>
      <li><a href="usuarios.php">👥 Usuarios</a></li>
      <li><a href="carreras.php">🏃 Carreras</a></li>
      <li><a href="inscripciones.php">📝 Inscripciones</a></li>
      <li><a href="logout.php">🚪 Salir</a></li>
    </ul>
  </div>

  <div class="content">
    <h1>Bienvenido al Panel de Administración</h1>
    <p>Desde aquí puedes gestionar todo el sistema de carreras:</p>
    <ul>
      <li>👥 Ver y administrar usuarios</li>
      <li>🏃 Crear y administrar carreras</li>
      <li>💳 Revisar métodos de pago</li>
      <li>📊 Consultar estadísticas</li>
    </ul>
  </div>
</body>
</html>
