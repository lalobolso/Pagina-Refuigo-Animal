<?php
include 'conexion.php';

if (isset($_GET['delete'])) {
    $idCarrera = intval($_GET['delete']);
    $conn->query("DELETE FROM carrera WHERE ID_Carrera=$idCarrera");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $fecha = $_POST['fecha'];
    $lugar = $_POST['lugar'];
    $descripcion = $_POST['descripcion'];
    $distancia = $_POST['distancia'];

    $sql = "INSERT INTO carrera (Nombre, Fecha, Lugar, Descripcion, Distancia, mostrar_resultados) 
            VALUES ('$nombre', '$fecha', '$lugar', '$descripcion', '$distancia', 0)";
    $conn->query($sql);
}

$result = $conn->query("SELECT * FROM carrera");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Carreras</title>
  <link rel="stylesheet" href="css/admin.css">
            <link rel="icon" href="img/Qubit.png" type="image/x-icon">

</head>
<body>
  <div class="sidebar">
    <h2>Admin</h2>
    <ul>
      <li><a href="admin.php">🏠 Dashboard</a></li>
      <li><a href="usuarios.php">👥 Usuarios</a></li>
      <li><a href="carreras.php">🏃 Carreras</a></li>
            <li><a href="inscripciones.php">📝 Inscripciones</a></li>
      <li><a href="logout.php">🚪 Salir</a></li>
    </ul>
  </div>

  <div class="content">
    <h1>Gestión de Carreras</h1>

    <h2>➕ Añadir Carrera</h2>
    <form method="POST">
      <label>Nombre:</label>
      <input type="text" name="nombre" required>

      <label>Fecha:</label>
      <input type="date" name="fecha" required>

      <label>Lugar:</label>
      <input type="text" name="lugar" required>

      <label>Descripción:</label>
      <textarea name="descripcion" rows="3" required></textarea>

      <label>Distancia (km):</label>
      <input type="text" name="distancia" required>

      <button type="submit">Añadir Carrera</button>
    </form>

    <!-- Listado de carreras -->
    <h2>📋 Listado de Carreras</h2>
    <table>
      <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Fecha</th>
        <th>Lugar</th>
        <th>Distancia</th>
        <th>Acciones</th>
      </tr>
      <?php while($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= $row['ID_Carrera'] ?></td>
          <td><?= $row['Nombre'] ?></td>
          <td><?= $row['Fecha'] ?></td>
          <td><?= $row['Lugar'] ?></td>
          <td><?= $row['Distancia'] ?> km</td>
          <td>
            <a href="participantes.php?id=<?= $row['ID_Carrera'] ?>">👥 Participantes</a> |
            <a href="carreras.php?delete=<?= $row['ID_Carrera'] ?>" 
               onclick="return confirm('¿Seguro que deseas eliminar esta carrera?')">🗑 Eliminar</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>
</body>
</html>
