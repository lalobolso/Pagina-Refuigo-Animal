<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $fecha = $_POST['fecha'];
    $lugar = $_POST['lugar'];
    $distancia = $_POST['distancia'];
    $descripcion = $_POST['descripcion'];
    $mostrar_resultados = isset($_POST['mostrar_resultados']) ? 1 : 0;

    $sql = "INSERT INTO carrera (Fecha, Lugar, Nombre, Descripcion, Distancia, mostrar_resultados)
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $fecha, $lugar, $nombre, $descripcion, $distancia, $mostrar_resultados);

    if ($stmt->execute()) {
        header("Location: admin.php#carreras");
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
